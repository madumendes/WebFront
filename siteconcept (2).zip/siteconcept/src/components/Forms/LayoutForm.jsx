import React from 'react';
import styled from 'styled-components';
import Header from './Header';
import QuoteForm from './QuoteForm';

const PageWrapper = styled.div`
  background-color: #fff;
  display: flex;
  flex-direction: column;
  overflow: hidden;
`;

const BackgroundImage = styled.img`
  position: absolute;
  inset: 0;
  height: 100%;
  width: 100%;
  object-fit: cover;
  object-position: center;
`;

const ContentWrapper = styled.main`
  display: flex;
  flex-direction: column;
  position: relative;
  min-height: 1024px;
  @media (max-width: 991px) {
    max-width: 100%;
  }
`;

function Layout() {
  return (
    <PageWrapper>
      <ContentWrapper>
        <BackgroundImage loading="lazy" src="https://cdn.builder.io/api/v1/image/assets/TEMP/18b3a6522e21742a4865645b313bbc9c0ed5d481cbd792fb0cec0eda55f72da7?apiKey=f395ac786dcf4f09956a3a9acd692f24&&apiKey=f395ac786dcf4f09956a3a9acd692f24" alt="Background" />
        <Header />
        <QuoteForm />
      </ContentWrapper>
    </PageWrapper>
  );
}

export default Layout;