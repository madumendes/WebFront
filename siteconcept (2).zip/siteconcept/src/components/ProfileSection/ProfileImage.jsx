import React from "react";
import styled from "styled-components";

const ProfileImage = ({ src, alt }) => {
  return <StyledImage loading="lazy" src={src} alt={alt} />;
};

const StyledImage = styled.img`
  aspect-ratio: 1;
  object-fit: contain;
  object-position: center;
  width: 50%;
  border-radius: 50%;
  flex-grow: 1;

  @media (max-width: 991px) {
    margin-top: 40px;
  }
`;

export default ProfileImage;