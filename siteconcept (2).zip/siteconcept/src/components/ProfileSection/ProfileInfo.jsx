import React from "react";
import styled from "styled-components";

const ProfileInfo = () => {
  return (
    <InfoContainer>
      <p>informações chefe da concept: é legal (nem sei)</p>
    </InfoContainer>
  );
};

const InfoContainer = styled.div`
  color: #000;
  letter-spacing: -0.48px;
  align-self: stretch;
  margin: auto 0;
  font: 600 24px/29px Inter, sans-serif;

  @media (max-width: 991px) {
    margin-top: 40px;
  }
`;

export default ProfileInfo;