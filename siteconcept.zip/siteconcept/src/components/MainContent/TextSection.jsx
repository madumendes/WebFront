import React from 'react';
import styled from 'styled-components';

const TextColumn = styled.div`
  display: flex;
  flex-direction: column;
  line-height: normal;
  width: 43%;
  margin-left: 0px;
  margin-right: 120px;
  @media (max-width: 991px) {
    width: 100%;
    margin-left: 0;
  }
`;

const TextContent = styled.div`
  width: 100%;
  border-radius: 10px;
  box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);
  background-color: #fff;
  position: relative;
  margin-top: 159px;
  color: #000;
  letter-spacing: -0.48px;
  padding: 59px 60px 59px 77px;
  font: 600 24px/29px Inter, sans-serif;
  @media (max-width: 991px) {
    max-width: 100%;
    margin-top: 40px;
    padding: 30px;
  }
`;

const textContents = [
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
  "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
  "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium."
];

const TextSection = ({ currentSlide }) => (
  <TextColumn>
    <TextContent>
      {textContents[currentSlide]}
    </TextContent>
  </TextColumn>
);

export default TextSection;